<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//Login
$lang['error_password'] = "You entered the incorrect password. The default password is password.";
$lang['password'] = "Password";
$lang['login'] = "Login";
$lang['infologin'] = 'Please enter the correct password';

//ControlPanel
$lang['easysite'] = "EasySite";
$lang['features'] = "Features";
$lang['settings'] = "Settings";
$lang['sint'] = "Social/Integration";
$lang['logoff'] = "Log off";
$lang['backup'] = "Backup";
//Welcome Page
$lang['welcome_content'] = "Welcome to Easy Site created by tecflare, this system was created to make web platforming easy and simple.
Our system allows you to add features to your website, without a database or any advanced technical skills.
You can also add many features to our system by using our plugin system. We have a market with a large selection
of different apps and products that will help your website grow. We hope you enjoy and you will choose easysite for creating
an awesome website. If you are a developer you should be able to edit our code because we are using codeigniter and it can improve
quality and design.";

//Settings Page
$lang['settingstag'] = 'Settings';
$lang['maintainance'] = 'Maintainance Mode';
$lang['submit'] = 'submit';
$lang['key'] = 'key';
$lang['language'] = 'language';
$lang['bkup_title'] = 'Backups keep your website safe';
?>