<?php
class plugin extends CI_Controller {
    

    
}
?>