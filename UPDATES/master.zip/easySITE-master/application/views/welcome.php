<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<h1>EasyPluginNote</h1>
<textarea></textarea>
<p><?php echo $this->lang->line('welcome_content'); ?>
</p>
