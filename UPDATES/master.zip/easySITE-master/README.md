# easySITE
easySITE can be imported into any website, its fast and light weight.

Lets make the IOT a better place.
## Installation of Wordpress
To install for wordpress, please READ THESE instructions.
1. Do not copy any of the files to wordpress
2. Visit this url, and download this file https://raw.githubusercontent.com/alwaysontop617/easySITE/master/wordpress.php.
3. Make sure this FILE is in the wordpress directory, the installer will make sure though.
4. Visit your website / wordpress.php and not the main wordpress page
5. Start the Installation.
6. After that delete the wordpress.php file for security reasons.

##Features

* Backup
* No MySQL database
* LightWeight
* Uses a Framework
* Maintainance Mode
* Plugins to expand functions.
* Password Protection
* Many More

##Screenshots
![plugins](https://i.imgsafe.org/000225146d.png)
![Get new Plugins](https://s32.postimg.org/ys4wll2np/screenshot.png)
![backups](https://i.imgsafe.org/0012917054.png)
